create extension if not exists pgcrypto;
create type public.app_role as enum ('owner','manager','employee','driver','customer');
create type public.account_status as enum ('active','inactive');
create type public.shipment_status as enum ('shipment_created','received_origin','ready_dispatch','in_transit','arrived_destination','out_for_delivery','delivery_attempted','delayed','returned_office','delivered');
create type public.payment_status as enum ('paid','unpaid','partial');

create table public.offices (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  address text,
  phone text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text unique,
  email text,
  role public.app_role not null default 'customer',
  status public.account_status not null default 'active',
  office_id uuid references public.offices(id),
  preferred_language text not null default 'en',
  created_at timestamptz not null default now()
);

create table public.pricing_settings (
  id uuid primary key default gen_random_uuid(),
  price_per_lb numeric(10,2) not null default 8.00,
  minimum_charge numeric(10,2) not null default 25.00,
  category_fee_percent numeric(6,3) not null default 30.000,
  additional_fee_percent numeric(6,3) not null default 11.500,
  poder_price numeric(10,2) not null default 35.00,
  active boolean not null default true,
  effective_from timestamptz not null default now(),
  changed_by uuid references public.profiles(id)
);

create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  tracking_number text not null unique,
  sender_name text not null,
  sender_phone text not null,
  sender_address text,
  receiver_name text not null,
  receiver_phone text not null,
  receiver_address text,
  origin_office_id uuid references public.offices(id),
  destination_office_id uuid references public.offices(id),
  assigned_driver_id uuid references public.profiles(id),
  contents text,
  special_notes text,
  total_weight_lb numeric(10,2) not null default 0,
  total_weight_kg numeric(10,2) not null default 0,
  declared_value numeric(12,2) not null default 0,
  category text,
  number_of_poderes integer not null default 0,
  shipping_charge numeric(12,2) not null default 0,
  category_fee numeric(12,2) not null default 0,
  additional_fee numeric(12,2) not null default 0,
  document_charge numeric(12,2) not null default 0,
  total_charge numeric(12,2) not null default 0,
  payment_status public.payment_status not null default 'unpaid',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.packages (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  package_number integer not null,
  package_tracking_number text not null unique,
  qr_payload text not null,
  weight_lb numeric(10,2) not null default 0,
  weight_kg numeric(10,2) not null default 0,
  contents text,
  status public.shipment_status not null default 'shipment_created',
  current_office_id uuid references public.offices(id),
  created_at timestamptz not null default now(),
  unique(shipment_id, package_number)
);

create table public.package_events (
  id uuid primary key default gen_random_uuid(),
  package_id uuid not null references public.packages(id) on delete cascade,
  previous_status public.shipment_status,
  new_status public.shipment_status not null,
  office_id uuid references public.offices(id),
  changed_by uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,phone,email,role)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Customer'),new.raw_user_meta_data->>'phone',new.email,'customer');
  return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into public.offices(name) values
('New York'),('Gotera'),('Santa Rosa'),('Polorós'),('La Unión'),('San Miguel')
on conflict(name) do nothing;

insert into public.pricing_settings(price_per_lb,minimum_charge,category_fee_percent,additional_fee_percent,poder_price)
select 8,25,30,11.5,35 where not exists(select 1 from public.pricing_settings);

alter table public.offices enable row level security;
alter table public.profiles enable row level security;
alter table public.pricing_settings enable row level security;
alter table public.shipments enable row level security;
alter table public.packages enable row level security;
alter table public.package_events enable row level security;

create policy "profiles_read_self" on public.profiles for select using(auth.uid()=id);
create policy "profiles_update_self" on public.profiles for update using(auth.uid()=id);
create policy "offices_read_authenticated" on public.offices for select to authenticated using(true);
create policy "pricing_read_authenticated" on public.pricing_settings for select to authenticated using(active=true);

create policy "shipments_read_allowed" on public.shipments for select to authenticated using(
  exists(select 1 from public.profiles p where p.id=auth.uid() and (
    p.role in ('owner','manager','employee')
    or (p.role='driver' and assigned_driver_id=p.id)
    or (p.role='customer' and (sender_phone=p.phone or receiver_phone=p.phone))
  ))
);

create policy "shipments_insert_staff" on public.shipments for insert to authenticated with check(
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('owner','manager','employee'))
);

create policy "shipments_update_staff" on public.shipments for update to authenticated using(
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('owner','manager','employee'))
);
